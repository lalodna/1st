package com.example.first;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent i = getIntent();
        //Return the intent that started this activity
        String name=i.getStringExtra("name");
        String age = i.getStringExtra("age");
        //this is used to get value which is passed in the Activity
        TextView t1=findViewById(R.id.textView);
        TextView t2 = findViewById(R.id.textView2);
        t1.setText(name);
        t2.setText(age);
    }
}